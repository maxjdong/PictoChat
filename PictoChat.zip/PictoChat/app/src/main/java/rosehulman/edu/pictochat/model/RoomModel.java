package rosehulman.edu.pictochat.model;

/**
 * Created by dongmj on 4/22/2018.
 */

public class RoomModel {

    String name;

    public RoomModel(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }
}
