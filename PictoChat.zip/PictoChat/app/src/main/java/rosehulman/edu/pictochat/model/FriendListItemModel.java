package rosehulman.edu.pictochat.model;
public class FriendListItemModel {
    
}
